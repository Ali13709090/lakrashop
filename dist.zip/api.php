<?php
/**
 * Lakra Shop - PHP API Middleware
 * این فایل واسط REST API برای اتصال React به دیتابیس SQLite است
 * برای هاست‌های اشتراکی که Python/Node پشتیبانی نمی‌کنند
 */

// ==================== Security Headers ====================
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Content-Type: application/json; charset=utf-8');

// ==================== CORS Headers ====================
$allowedOrigins = ['*']; // در پروداکشن دامنه خودتون رو بذارید مثلاً: ['https://yourdomain.com']
$origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
if (in_array('*', $allowedOrigins) || in_array($origin, $allowedOrigins)) {
    header("Access-Control-Allow-Origin: $origin");
}
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Max-Age: 86400');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ==================== Configuration ====================
define('DB_DIR', __DIR__ . '/..');
define('DB_PATH', DB_DIR . '/lakra_shop.db');
define('UPLOAD_DIR', __DIR__ . '/../uploads/products/');
define('SECRET_KEY', 'lakra-shop-secret-key-change-in-production-2024');
define('TOKEN_EXPIRY', 86400); // 24 hours
define('ADMIN_EMAIL', 'ali.bahmani557@gmail.com');
define('ADMIN_PASSWORD_HASH', hash('sha256', 'ali137090'));
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['png', 'jpg', 'jpeg', 'gif', 'webp']);

// Rate Limiting Config
define('RATE_LIMIT_WINDOW', 60);     // 60 seconds
define('RATE_LIMIT_MAX', 120);       // max requests per window
define('RATE_LIMIT_LOGIN_MAX', 5);   // max login attempts per window
define('RATE_LIMIT_DIR', DB_DIR . '/.rate_limits');

// ==================== Rate Limiting ====================
function checkRateLimit($endpoint = 'general') {
    if (!is_dir(RATE_LIMIT_DIR)) {
        @mkdir(RATE_LIMIT_DIR, 0755, true);
    }
    
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $key = md5($ip . '_' . $endpoint);
    $file = RATE_LIMIT_DIR . '/' . $key . '.json';
    
    $maxRequests = ($endpoint === 'auth/login') ? RATE_LIMIT_LOGIN_MAX : RATE_LIMIT_MAX;
    $now = time();
    
    $data = ['requests' => [], 'blocked_until' => 0];
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true) ?: $data;
    }
    
    // Check if blocked
    if ($data['blocked_until'] > $now) {
        $remaining = $data['blocked_until'] - $now;
        jsonResponse(['success' => false, 'error' => "درخواست‌های شما محدود شده. $remaining ثانیه صبر کنید."], 429);
    }
    
    // Remove old requests outside window
    $data['requests'] = array_filter($data['requests'], function($t) use ($now) {
        return $t > ($now - RATE_LIMIT_WINDOW);
    });
    
    // Check if over limit
    if (count($data['requests']) >= $maxRequests) {
        $data['blocked_until'] = $now + RATE_LIMIT_WINDOW;
        @file_put_contents($file, json_encode($data));
        jsonResponse(['success' => false, 'error' => 'تعداد درخواست‌ها بیش از حد مجاز. لطفاً کمی صبر کنید.'], 429);
    }
    
    // Log request
    $data['requests'][] = $now;
    @file_put_contents($file, json_encode($data));
    
    // Cleanup old rate limit files (1 in 100 chance)
    if (mt_rand(1, 100) === 1) {
        foreach (glob(RATE_LIMIT_DIR . '/*.json') as $f) {
            if (filemtime($f) < ($now - 3600)) @unlink($f);
        }
    }
}

// ==================== Token Storage (File-based for shared hosting) ====================
define('TOKEN_FILE', __DIR__ . '/../.tokens.json');

function getActiveTokens() {
    if (!file_exists(TOKEN_FILE)) {
        return [];
    }
    $content = file_get_contents(TOKEN_FILE);
    return json_decode($content, true) ?: [];
}

function saveActiveTokens($tokens) {
    file_put_contents(TOKEN_FILE, json_encode($tokens));
}

function generateToken($userId, $role = 'user') {
    $timestamp = time();
    $random = bin2hex(random_bytes(16));
    $tokenData = "$userId:$role:$timestamp:$random";
    $signature = hash_hmac('sha256', $tokenData, SECRET_KEY);
    $token = "$tokenData:$signature";
    
    $tokens = getActiveTokens();
    $tokens[$token] = [
        'user_id' => $userId,
        'role' => $role,
        'created_at' => $timestamp,
        'expires_at' => $timestamp + TOKEN_EXPIRY
    ];
    
    // Clean expired tokens
    $tokens = array_filter($tokens, function($t) {
        return $t['expires_at'] > time();
    });
    
    saveActiveTokens($tokens);
    return $token;
}

function verifyToken($token) {
    if (!$token) return null;
    
    $tokens = getActiveTokens();
    if (!isset($tokens[$token])) return null;
    
    $tokenInfo = $tokens[$token];
    
    if (time() > $tokenInfo['expires_at']) {
        unset($tokens[$token]);
        saveActiveTokens($tokens);
        return null;
    }
    
    return $tokenInfo;
}

function getBearerToken() {
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        return str_replace('Bearer ', '', $headers['Authorization']);
    }
    // Try lowercase
    if (isset($headers['authorization'])) {
        return str_replace('Bearer ', '', $headers['authorization']);
    }
    // Fallback: Apache mod_rewrite passes header via env variable (cPanel shared hosting)
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        return str_replace('Bearer ', '', $_SERVER['HTTP_AUTHORIZATION']);
    }
    if (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        return str_replace('Bearer ', '', $_SERVER['REDIRECT_HTTP_AUTHORIZATION']);
    }
    return null;
}

function requireAdmin() {
    $token = getBearerToken();
    $tokenInfo = verifyToken($token);
    
    if (!$tokenInfo || $tokenInfo['role'] !== 'admin') {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'دسترسی غیرمجاز']);
        exit();
    }
    return $tokenInfo;
}

// ==================== Database Connection ====================
function getDB() {
    try {
        $db = new PDO('sqlite:' . DB_PATH);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->exec("PRAGMA foreign_keys = ON");
        return $db;
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'خطا در اتصال به دیتابیس: ' . $e->getMessage()]);
        exit();
    }
}

// ==================== Helper Functions ====================
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

function getRequestBody() {
    $json = file_get_contents('php://input');
    return json_decode($json, true) ?: [];
}

function sanitizeFilename($filename) {
    $filename = basename($filename);
    return preg_replace('/[^a-zA-Z0-9_.-]/', '', $filename);
}

function allowedFile($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ALLOWED_EXTENSIONS);
}

// Product columns for mapping
function getProductColumns() {
    return [
        'id', 'name', 'barcode', 'buy_price', 'sell_price', 'cover_price',
        'discount', 'quantity', 'min_stock', 'production_date', 'expiration_date',
        'brand', 'category', 'subcategory', 'description', 'usage',
        'images', 'features', 'colors', 'volumes', 'shades', 'skin_types',
        'rating', 'review_count', 'is_new', 'is_bestseller', 'is_featured',
        'is_active', 'created_at', 'updated_at', 'source'
    ];
}

function rowToProduct($row) {
    $columns = getProductColumns();
    $jsonFields = ['images', 'features', 'colors', 'volumes', 'shades', 'skin_types'];
    
    $product = [];
    foreach ($columns as $i => $col) {
        if (isset($row[$col])) {
            $value = $row[$col];
            if (in_array($col, $jsonFields)) {
                $product[$col] = $value ? json_decode($value, true) : [];
            } else {
                $product[$col] = $value;
            }
        } elseif (isset($row[$i])) {
            $value = $row[$i];
            if (in_array($col, $jsonFields)) {
                $product[$col] = $value ? json_decode($value, true) : [];
            } else {
                $product[$col] = $value;
            }
        }
    }
    
    // Calculate final price for website
    $price = $product['sell_price'] ?? 0;
    $discount = $product['discount'] ?? 0;
    $product['price'] = $price;
    $product['finalPrice'] = $discount > 0 ? $price - ($price * $discount / 100) : $price;
    $product['stock'] = $product['quantity'] ?? 0;
    $product['isBestseller'] = (bool)($product['is_bestseller'] ?? 0);
    $product['isNew'] = (bool)($product['is_new'] ?? 0);
    
    return $product;
}

// ==================== Database Initialization ====================

function ensureOnlineOrdersTable($db) {
    // Create table if not exists
    $db->exec("CREATE TABLE IF NOT EXISTS online_orders (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        customer_name TEXT,
        customer_phone TEXT,
        customer_email TEXT,
        items TEXT,
        total_amount REAL,
        subtotal REAL,
        shipping_cost REAL DEFAULT 0,
        discount_amount REAL DEFAULT 0,
        coupon_code TEXT,
        shipping_address TEXT,
        payment_method TEXT,
        shipping_method TEXT,
        status TEXT DEFAULT 'pending',
        notes TEXT,
        created_at TEXT,
        updated_at TEXT
    )");
    
    // Migrate: add missing columns to existing table
    $requiredCols = [
        'customer_name' => 'TEXT',
        'customer_phone' => 'TEXT',
        'customer_email' => 'TEXT',
        'subtotal' => 'REAL',
        'shipping_cost' => 'REAL DEFAULT 0',
        'discount_amount' => 'REAL DEFAULT 0',
        'coupon_code' => 'TEXT',
        'shipping_address' => 'TEXT',
        'payment_method' => 'TEXT',
        'shipping_method' => 'TEXT',
        'notes' => 'TEXT',
        'updated_at' => 'TEXT'
    ];
    
    try {
        $cols = $db->query("PRAGMA table_info(online_orders)")->fetchAll(PDO::FETCH_ASSOC);
        $existingCols = array_column($cols, 'name');
        
        foreach ($requiredCols as $col => $type) {
            if (!in_array($col, $existingCols)) {
                $db->exec("ALTER TABLE online_orders ADD COLUMN $col $type");
            }
        }
    } catch (PDOException $e) {
        // Ignore ALTER errors
    }
}

function ensureTables() {
    $db = getDB();
    
    // Reviews table
    $db->exec("CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        product_name TEXT,
        user_id TEXT,
        user_name TEXT,
        user_email TEXT,
        rating INTEGER DEFAULT 5,
        comment TEXT,
        status TEXT DEFAULT 'pending',
        likes INTEGER DEFAULT 0,
        created_at TEXT,
        updated_at TEXT
    )");
    
    // Customers table
    $db->exec("CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT,
        phone TEXT,
        address TEXT,
        postal_code TEXT,
        province TEXT,
        city TEXT,
        orders_count INTEGER DEFAULT 0,
        total_spent REAL DEFAULT 0,
        is_vip INTEGER DEFAULT 0,
        created_at TEXT,
        updated_at TEXT
    )");
    
    // Users table (for registration)
    // Check if table exists with correct schema
    $usersTableOk = false;
    try {
        $check = $db->query("PRAGMA table_info(users)");
        $cols = $check->fetchAll(PDO::FETCH_ASSOC);
        $colNames = array_column($cols, 'name');
        if (in_array('email', $colNames) && in_array('password_hash', $colNames)) {
            $usersTableOk = true;
        } else if (count($cols) > 0) {
            // Table exists but with wrong schema - recreate
            $db->exec("DROP TABLE users");
        }
    } catch (PDOException $e) { /* table doesn't exist */ }
    
    if (!$usersTableOk) {
        $db->exec("CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at TEXT,
            updated_at TEXT
        )");
    }
    
    // Coupons table
    $db->exec("CREATE TABLE IF NOT EXISTS coupons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        type TEXT DEFAULT 'percent',
        value REAL NOT NULL,
        min_purchase REAL DEFAULT 0,
        max_discount REAL DEFAULT 0,
        usage_limit INTEGER DEFAULT 0,
        used_count INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        expires_at TEXT,
        created_at TEXT,
        updated_at TEXT
    )");
    
    return $db;
}

// ==================== API Endpoints ====================

// --- Authentication ---
function handleLogin() {
    checkRateLimit('auth/login');
    $data = getRequestBody();
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';
    
    $passwordHash = hash('sha256', $password);
    
    // Check admin
    if ($email === ADMIN_EMAIL && $passwordHash === ADMIN_PASSWORD_HASH) {
        $token = generateToken('admin', 'admin');
        jsonResponse([
            'success' => true,
            'token' => $token,
            'user' => [
                'id' => 'admin',
                'email' => $email,
                'role' => 'admin',
                'name' => 'مدیر سیستم'
            ]
        ]);
    }
    
    // Check registered users
    $db = ensureTables();
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && $user['password_hash'] === $passwordHash) {
            $token = generateToken($user['id'], 'user');
            jsonResponse([
                'success' => true,
                'token' => $token,
                'user' => [
                    'id' => $user['id'],
                    'email' => $user['email'],
                    'name' => $user['name'],
                    'phone' => $user['phone'],
                    'role' => 'user'
                ]
            ]);
        }
    } catch (PDOException $e) {
        // Continue to fail
    }
    
    jsonResponse(['success' => false, 'error' => 'ایمیل یا رمز عبور اشتباه است'], 401);
}

function handleRegister() {
    checkRateLimit('auth/login');
    $data = getRequestBody();
    $name = trim($data['name'] ?? '');
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $password = $data['password'] ?? '';
    
    if (!$name || !$email || !$password) {
        jsonResponse(['success' => false, 'error' => 'نام، ایمیل و رمز عبور الزامی است'], 400);
    }
    
    $db = ensureTables();
    $now = date('Y-m-d H:i:s');
    
    try {
        // Check if email exists
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'error' => 'این ایمیل قبلا ثبت شده است'], 400);
        }
        
        $passwordHash = hash('sha256', $password);
        
        $stmt = $db->prepare("INSERT INTO users (name, email, phone, password_hash, role, created_at, updated_at) VALUES (?, ?, ?, ?, 'user', ?, ?)");
        $stmt->execute([$name, $email, $phone, $passwordHash, $now, $now]);
        
        $userId = $db->lastInsertId();
        $token = generateToken($userId, 'user');
        
        // Also add to customers table
        $stmt = $db->prepare("INSERT OR IGNORE INTO customers (name, email, phone, created_at, updated_at) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $phone, $now, $now]);
        
        jsonResponse([
            'success' => true,
            'token' => $token,
            'user' => [
                'id' => $userId,
                'email' => $email,
                'name' => $name,
                'phone' => $phone,
                'role' => 'user'
            ]
        ], 201);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleVerifyAuth() {
    $token = getBearerToken();
    $tokenInfo = verifyToken($token);
    
    if ($tokenInfo) {
        jsonResponse([
            'success' => true,
            'valid' => true,
            'role' => $tokenInfo['role']
        ]);
    }
    
    jsonResponse(['success' => false, 'valid' => false], 401);
}

function handleLogout() {
    $token = getBearerToken();
    if ($token) {
        $tokens = getActiveTokens();
        unset($tokens[$token]);
        saveActiveTokens($tokens);
    }
    jsonResponse(['success' => true, 'message' => 'با موفقیت خارج شدید']);
}

// --- Products ---
function handleGetProducts() {
    $db = getDB();
    
    $category = $_GET['category'] ?? null;
    $search = $_GET['search'] ?? null;
    $activeOnly = ($_GET['active'] ?? 'true') !== 'false';
    
    $sql = "SELECT * FROM products WHERE 1=1";
    $params = [];
    
    if ($activeOnly) {
        $sql .= " AND is_active = 1";
    }
    
    if ($search) {
        $sql .= " AND (name LIKE ? OR brand LIKE ? OR description LIKE ?)";
        $searchTerm = "%$search%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
    }
    
    if ($category) {
        $sql .= " AND category = ?";
        $params[] = $category;
    }
    
    $sql .= " ORDER BY id DESC";
    
    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $products = array_map('rowToProduct', $rows);
        
        jsonResponse([
            'success' => true,
            'data' => $products,
            'count' => count($products)
        ]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleGetProduct($id) {
    $db = getDB();
    
    try {
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$row) {
            jsonResponse(['success' => false, 'error' => 'محصول یافت نشد'], 404);
        }
        
        $product = rowToProduct($row);
        jsonResponse(['success' => true, 'data' => $product]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleCreateProduct() {
    $db = getDB();
    $data = getRequestBody();
    
    if (empty($data['name'])) {
        jsonResponse(['success' => false, 'error' => 'فیلد name الزامی است'], 400);
    }
    
    // Generate barcode if not provided
    if (empty($data['barcode'])) {
        $data['barcode'] = 'AUTO_' . round(microtime(true) * 1000);
    }
    
    // Map website fields to database fields
    if (isset($data['price']) && !isset($data['sell_price'])) {
        $data['sell_price'] = $data['price'];
    }
    if (isset($data['stock']) && !isset($data['quantity'])) {
        $data['quantity'] = $data['stock'];
    }
    
    $now = date('Y-m-d H:i:s');
    
    try {
        $sql = "INSERT INTO products (
            name, barcode, buy_price, sell_price, cover_price, discount,
            quantity, min_stock, production_date, expiration_date,
            brand, category, subcategory,
            description, `usage`, images, features, colors, volumes, shades, skin_types,
            is_new, is_bestseller, is_featured, is_active,
            created_at, updated_at, source
        ) VALUES (
            ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?
        )";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([
            $data['name'],
            $data['barcode'],
            $data['buy_price'] ?? 0,
            floatval($data['sell_price'] ?? 0),
            $data['cover_price'] ?? 0,
            intval($data['discount'] ?? 0),
            intval($data['quantity'] ?? 0),
            $data['min_stock'] ?? 5,
            $data['production_date'] ?? null,
            $data['expiration_date'] ?? null,
            $data['brand'] ?? null,
            $data['category'] ?? null,
            $data['subcategory'] ?? null,
            $data['description'] ?? null,
            $data['usage'] ?? null,
            json_encode($data['images'] ?? []),
            json_encode($data['features'] ?? []),
            json_encode($data['colors'] ?? []),
            json_encode($data['volumes'] ?? []),
            json_encode($data['shades'] ?? []),
            json_encode($data['skin_types'] ?? []),
            $data['is_new'] ?? 0,
            $data['is_bestseller'] ?? 0,
            $data['is_featured'] ?? 0,
            $data['is_active'] ?? 1,
            $now,
            $now,
            'website'
        ]);
        
        $productId = $db->lastInsertId();
        
        jsonResponse([
            'success' => true,
            'message' => 'محصول با موفقیت ایجاد شد',
            'product_id' => $productId
        ], 201);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleUpdateProduct($id) {
    $db = getDB();
    $data = getRequestBody();
    
    // Build dynamic UPDATE query
    $fields = [];
    $values = [];
    
    $allowedFields = [
        'name', 'barcode', 'buy_price', 'sell_price', 'cover_price', 'discount',
        'quantity', 'min_stock', 'production_date', 'expiration_date',
        'brand', 'category', 'subcategory',
        'description', 'usage', 'images', 'features', 'colors', 'volumes', 'shades', 'skin_types',
        'is_new', 'is_bestseller', 'is_featured', 'is_active'
    ];
    
    $jsonFields = ['images', 'features', 'colors', 'volumes', 'shades', 'skin_types'];
    
    // Map website fields
    if (isset($data['price']) && !isset($data['sell_price'])) {
        $data['sell_price'] = $data['price'];
    }
    if (isset($data['stock']) && !isset($data['quantity'])) {
        $data['quantity'] = $data['stock'];
    }
    
    foreach ($data as $key => $value) {
        if (in_array($key, $allowedFields)) {
            $fieldName = $key === 'usage' ? '`usage`' : $key;
            $fields[] = "$fieldName = ?";
            
            if (in_array($key, $jsonFields) && is_array($value)) {
                $values[] = json_encode($value);
            } elseif (in_array($key, ['sell_price', 'buy_price', 'cover_price'])) {
                $values[] = floatval($value);
            } elseif (in_array($key, ['quantity', 'discount', 'min_stock'])) {
                $values[] = intval($value);
            } else {
                $values[] = $value;
            }
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['success' => false, 'error' => 'هیچ فیلدی برای بروزرسانی ارسال نشده'], 400);
    }
    
    $fields[] = "updated_at = ?";
    $values[] = date('Y-m-d H:i:s');
    $fields[] = "source = ?";
    $values[] = 'website';
    $values[] = $id;
    
    try {
        $sql = "UPDATE products SET " . implode(', ', $fields) . " WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute($values);
        
        if ($stmt->rowCount() === 0) {
            jsonResponse(['success' => false, 'error' => 'محصول یافت نشد'], 404);
        }
        
        jsonResponse(['success' => true, 'message' => 'محصول با موفقیت بروزرسانی شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleDeleteProduct($id) {
    $db = getDB();
    
    try {
        $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() === 0) {
            jsonResponse(['success' => false, 'error' => 'محصول یافت نشد'], 404);
        }
        
        jsonResponse(['success' => true, 'message' => 'محصول با موفقیت حذف شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// --- Orders ---
function handleCreateOrder() {
    $db = ensureTables();
    $data = getRequestBody();
    
    // Ensure online_orders table has all required columns
    ensureOnlineOrdersTable($db);
    
    $now = date('Y-m-d H:i:s');
    $orderId = $data['order_id'] ?? ('ORD-' . substr(time(), -6));
    
    try {
        $sql = "INSERT INTO online_orders (id, user_id, customer_name, customer_phone, customer_email, items, total_amount, subtotal, shipping_cost, discount_amount, coupon_code, shipping_address, payment_method, shipping_method, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([
            $orderId,
            $data['user_id'] ?? '',
            $data['customer_name'] ?? '',
            $data['customer_phone'] ?? '',
            $data['customer_email'] ?? '',
            is_array($data['items']) ? json_encode($data['items']) : ($data['items'] ?? '[]'),
            floatval($data['total_amount'] ?? 0),
            floatval($data['subtotal'] ?? 0),
            floatval($data['shipping_cost'] ?? 0),
            floatval($data['discount_amount'] ?? 0),
            $data['coupon_code'] ?? '',
            is_array($data['shipping_address']) ? json_encode($data['shipping_address']) : ($data['shipping_address'] ?? ''),
            $data['payment_method'] ?? 'online',
            $data['shipping_method'] ?? 'normal',
            $now,
            $now
        ]);
        
        // Use coupon if provided
        if (!empty($data['coupon_code'])) {
            incrementCouponUsage($db, $data['coupon_code']);
        }
        
        // Deduct inventory for each item
        $items = is_array($data['items']) ? $data['items'] : json_decode($data['items'] ?? '[]', true);
        if (is_array($items)) {
            deductInventory($db, $items);
        }
        
        jsonResponse(['success' => true, 'message' => 'سفارش با موفقیت ثبت شد', 'order_id' => $orderId], 201);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleGetOrders() {
    $db = ensureTables();
    
    // Ensure online_orders table has all required columns
    ensureOnlineOrdersTable($db);
    
    try {
        // Support filtering by user_id for customer profile
        $userId = $_GET['user_id'] ?? null;
        if ($userId) {
            $stmt = $db->prepare("SELECT * FROM online_orders WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$userId]);
        } else {
            $stmt = $db->query("SELECT * FROM online_orders ORDER BY created_at DESC");
        }
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $orders = [];
        foreach ($rows as $row) {
            $orders[] = [
                'id' => $row['id'],
                'user_id' => $row['user_id'] ?? '',
                'customer_name' => $row['customer_name'] ?? '',
                'customer_phone' => $row['customer_phone'] ?? '',
                'customer_email' => $row['customer_email'] ?? '',
                'items' => json_decode($row['items'] ?? '[]', true) ?: [],
                'total_amount' => floatval($row['total_amount'] ?? 0),
                'subtotal' => floatval($row['subtotal'] ?? 0),
                'shipping_cost' => floatval($row['shipping_cost'] ?? 0),
                'discount_amount' => floatval($row['discount_amount'] ?? 0),
                'coupon_code' => $row['coupon_code'] ?? '',
                'shipping_address' => json_decode($row['shipping_address'] ?? '', true) ?: $row['shipping_address'],
                'payment_method' => $row['payment_method'] ?? '',
                'shipping_method' => $row['shipping_method'] ?? '',
                'status' => $row['status'] ?? 'pending',
                'notes' => $row['notes'] ?? '',
                'created_at' => $row['created_at'] ?? '',
                'updated_at' => $row['updated_at'] ?? ''
            ];
        }
        
        jsonResponse(['success' => true, 'data' => $orders]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleUpdateOrderStatus($orderId) {
    $db = getDB();
    ensureOnlineOrdersTable($db);
    $data = getRequestBody();
    
    if (empty($data['status'])) {
        jsonResponse(['success' => false, 'error' => 'فیلد status الزامی است'], 400);
    }
    
    $newStatus = $data['status'];
    
    try {
        // Get current order to check old status and items
        $stmtOld = $db->prepare("SELECT status, items, coupon_code FROM online_orders WHERE id = ?");
        $stmtOld->execute([$orderId]);
        $oldOrder = $stmtOld->fetch(PDO::FETCH_ASSOC);
        
        if (!$oldOrder) {
            jsonResponse(['success' => false, 'error' => 'سفارش یافت نشد'], 404);
        }
        
        $oldStatus = $oldOrder['status'];
        $items = json_decode($oldOrder['items'] ?? '[]', true) ?: [];
        
        // Update status
        $stmt = $db->prepare("UPDATE online_orders SET status = ?, updated_at = ? WHERE id = ?");
        $stmt->execute([$newStatus, date('Y-m-d H:i:s'), $orderId]);
        
        // Handle inventory changes on cancel/uncancel
        if ($newStatus === 'cancelled' && $oldStatus !== 'cancelled') {
            // Restore inventory when cancelling
            restoreInventory($db, $items);
            // Restore coupon usage
            if (!empty($oldOrder['coupon_code'])) {
                decrementCouponUsage($db, $oldOrder['coupon_code']);
            }
        } elseif ($oldStatus === 'cancelled' && $newStatus !== 'cancelled') {
            // Re-deduct inventory when un-cancelling
            deductInventory($db, $items);
            // Re-use coupon
            if (!empty($oldOrder['coupon_code'])) {
                incrementCouponUsage($db, $oldOrder['coupon_code']);
            }
        }
        
        jsonResponse(['success' => true, 'message' => 'وضعیت سفارش بروزرسانی شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// --- Inventory ---
function handleGetLowStock() {
    $db = getDB();
    $threshold = isset($_GET['threshold']) ? intval($_GET['threshold']) : null;
    
    try {
        $sql = "SELECT id, name, barcode, quantity, min_stock FROM products WHERE quantity <= " . 
               ($threshold ? "?" : "min_stock");
        
        $stmt = $db->prepare($sql);
        $stmt->execute($threshold ? [$threshold] : []);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['success' => true, 'data' => $rows, 'count' => count($rows)]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleGetInventoryHistory() {
    $db = getDB();
    $productId = $_GET['product_id'] ?? null;
    $limit = intval($_GET['limit'] ?? 100);
    
    try {
        $sql = "SELECT h.*, p.name as product_name, p.barcode 
                FROM inventory_history h 
                LEFT JOIN products p ON h.product_id = p.id";
        
        $params = [];
        if ($productId) {
            $sql .= " WHERE h.product_id = ?";
            $params[] = $productId;
        }
        
        $sql .= " ORDER BY h.created_at DESC LIMIT ?";
        $params[] = $limit;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['success' => true, 'data' => $rows]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// --- Sales ---
function handleGetSales() {
    $db = getDB();
    $limit = intval($_GET['limit'] ?? 100);
    
    try {
        $stmt = $db->prepare("SELECT * FROM sales ORDER BY date DESC LIMIT ?");
        $stmt->execute([$limit]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['success' => true, 'data' => $rows]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleGetSalesReport() {
    $db = getDB();
    $startDate = $_GET['start_date'] ?? null;
    $endDate = $_GET['end_date'] ?? null;
    
    try {
        $sql = "SELECT COUNT(*) as sale_count, 
                       SUM(quantity) as total_items,
                       SUM(total_price) as total_revenue,
                       SUM(profit) as total_profit
                FROM sales WHERE 1=1";
        
        $params = [];
        if ($startDate) {
            $sql .= " AND date >= ?";
            $params[] = $startDate;
        }
        if ($endDate) {
            $sql .= " AND date <= ?";
            $params[] = "$endDate 23:59:59";
        }
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        jsonResponse([
            'success' => true,
            'data' => [
                'sale_count' => intval($row['sale_count'] ?? 0),
                'total_items' => intval($row['total_items'] ?? 0),
                'total_revenue' => floatval($row['total_revenue'] ?? 0),
                'total_profit' => floatval($row['total_profit'] ?? 0)
            ]
        ]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// --- Dashboard Stats ---
function handleGetDashboardStats() {
    $db = getDB();
    
    try {
        // Total products
        $stmt = $db->query("SELECT COUNT(*) FROM products WHERE is_active = 1");
        $totalProducts = $stmt->fetchColumn();
        
        // Low stock count
        $stmt = $db->query("SELECT COUNT(*) FROM products WHERE quantity <= min_stock AND is_active = 1");
        $lowStockCount = $stmt->fetchColumn();
        
        // Today's sales
        $today = date('Y-m-d');
        $stmt = $db->prepare("SELECT COUNT(*), SUM(total_price), SUM(profit) FROM sales WHERE date LIKE ?");
        $stmt->execute(["$today%"]);
        $todayStats = $stmt->fetch(PDO::FETCH_NUM);
        
        // Total sales
        $stmt = $db->query("SELECT COUNT(*), SUM(total_price), SUM(profit) FROM sales");
        $totalStats = $stmt->fetch(PDO::FETCH_NUM);
        
        jsonResponse([
            'success' => true,
            'data' => [
                'total_products' => intval($totalProducts),
                'low_stock_count' => intval($lowStockCount),
                'today_sales' => [
                    'count' => intval($todayStats[0] ?? 0),
                    'revenue' => floatval($todayStats[1] ?? 0),
                    'profit' => floatval($todayStats[2] ?? 0)
                ],
                'total_sales' => [
                    'count' => intval($totalStats[0] ?? 0),
                    'revenue' => floatval($totalStats[1] ?? 0),
                    'profit' => floatval($totalStats[2] ?? 0)
                ]
            ]
        ]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// --- File Upload ---
function handleUploadImage() {
    if (!isset($_FILES['file'])) {
        jsonResponse(['success' => false, 'error' => 'فایلی انتخاب نشده است'], 400);
    }
    
    $file = $_FILES['file'];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        jsonResponse(['success' => false, 'error' => 'خطا در آپلود فایل'], 400);
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        jsonResponse(['success' => false, 'error' => 'حداکثر حجم فایل 5 مگابایت است'], 400);
    }
    
    if (!allowedFile($file['name'])) {
        jsonResponse(['success' => false, 'error' => 'فرمت فایل مجاز نیست. فرمت‌های مجاز: png, jpg, jpeg, gif, webp'], 400);
    }
    
    // Validate image content
    $imageInfo = getimagesize($file['tmp_name']);
    if ($imageInfo === false) {
        jsonResponse(['success' => false, 'error' => 'فایل یک تصویر معتبر نیست'], 400);
    }
    
    // Generate unique filename
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $uniqueFilename = bin2hex(random_bytes(16)) . '.' . $ext;
    
    // Create upload directory if not exists
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    
    $filepath = UPLOAD_DIR . $uniqueFilename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        $imageUrl = "/uploads/products/$uniqueFilename";
        jsonResponse([
            'success' => true,
            'url' => $imageUrl,
            'filename' => $uniqueFilename
        ]);
    }
    
    jsonResponse(['success' => false, 'error' => 'خطا در ذخیره فایل'], 500);
}

function handleDeleteImage() {
    requireAdmin();
    
    $data = getRequestBody();
    $filename = $data['filename'] ?? '';
    
    if (!$filename) {
        jsonResponse(['success' => false, 'error' => 'نام فایل مشخص نشده است'], 400);
    }
    
    // Security: only allow filename, not path
    $filename = basename($filename);
    $filename = sanitizeFilename($filename);
    
    if (!$filename) {
        jsonResponse(['success' => false, 'error' => 'نام فایل نامعتبر'], 400);
    }
    
    $filepath = UPLOAD_DIR . $filename;
    
    if (file_exists($filepath)) {
        unlink($filepath);
        jsonResponse(['success' => true, 'message' => 'تصویر حذف شد']);
    }
    
    jsonResponse(['success' => false, 'error' => 'فایل یافت نشد'], 404);
}

// --- Health Check ---
function handleHealthCheck() {
    try {
        $db = getDB();
        $stmt = $db->query("SELECT 1");
        jsonResponse([
            'success' => true,
            'database' => 'connected',
            'server_time' => date('Y-m-d H:i:s')
        ]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'error' => 'Database error'], 500);
    }
}

// --- Reviews ---
function handleGetReviews() {
    $db = ensureTables();
    $productId = $_GET['product_id'] ?? null;
    $status = $_GET['status'] ?? null;
    
    try {
        $sql = "SELECT * FROM reviews WHERE 1=1";
        $params = [];
        
        if ($productId) {
            $sql .= " AND product_id = ?";
            $params[] = $productId;
        }
        if ($status) {
            $sql .= " AND status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['success' => true, 'data' => $rows]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleCreateReview() {
    $db = ensureTables();
    $data = getRequestBody();
    
    if (empty($data['product_id']) || empty($data['comment'])) {
        jsonResponse(['success' => false, 'error' => 'شناسه محصول و نظر الزامی است'], 400);
    }
    
    $now = date('Y-m-d H:i:s');
    
    try {
        $stmt = $db->prepare("INSERT INTO reviews (product_id, product_name, user_id, user_name, user_email, rating, comment, status, likes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', 0, ?, ?)");
        $stmt->execute([
            $data['product_id'],
            $data['product_name'] ?? '',
            $data['user_id'] ?? '',
            $data['user_name'] ?? 'کاربر',
            $data['user_email'] ?? '',
            intval($data['rating'] ?? 5),
            $data['comment'],
            $now,
            $now
        ]);
        
        $reviewId = $db->lastInsertId();
        jsonResponse(['success' => true, 'message' => 'نظر ثبت شد', 'review_id' => $reviewId], 201);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleUpdateReview($id) {
    requireAdmin();
    $db = ensureTables();
    $data = getRequestBody();
    
    $fields = [];
    $values = [];
    
    if (isset($data['status'])) {
        $fields[] = "status = ?";
        $values[] = $data['status'];
    }
    if (isset($data['likes'])) {
        $fields[] = "likes = ?";
        $values[] = intval($data['likes']);
    }
    
    if (empty($fields)) {
        jsonResponse(['success' => false, 'error' => 'داده‌ای ارسال نشده'], 400);
    }
    
    $fields[] = "updated_at = ?";
    $values[] = date('Y-m-d H:i:s');
    $values[] = $id;
    
    try {
        $stmt = $db->prepare("UPDATE reviews SET " . implode(', ', $fields) . " WHERE id = ?");
        $stmt->execute($values);
        jsonResponse(['success' => true, 'message' => 'نظر بروزرسانی شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleDeleteReview($id) {
    requireAdmin();
    $db = ensureTables();
    
    try {
        $stmt = $db->prepare("DELETE FROM reviews WHERE id = ?");
        $stmt->execute([$id]);
        jsonResponse(['success' => true, 'message' => 'نظر حذف شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// --- Customers ---
function handleGetCustomers() {
    requireAdmin();
    $db = ensureTables();
    
    try {
        $stmt = $db->query("SELECT * FROM customers ORDER BY created_at DESC");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse(['success' => true, 'data' => $rows]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleCreateOrUpdateCustomer() {
    $db = ensureTables();
    $data = getRequestBody();
    $now = date('Y-m-d H:i:s');
    
    $email = $data['email'] ?? '';
    $phone = $data['phone'] ?? '';
    
    try {
        // Check if customer exists
        $existing = null;
        if ($email) {
            $stmt = $db->prepare("SELECT * FROM customers WHERE email = ?");
            $stmt->execute([$email]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        if (!$existing && $phone) {
            $stmt = $db->prepare("SELECT * FROM customers WHERE phone = ?");
            $stmt->execute([$phone]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        
        if ($existing) {
            $orderTotal = floatval($data['order_total'] ?? 0);
            $stmt = $db->prepare("UPDATE customers SET name = COALESCE(?, name), phone = COALESCE(?, phone), address = COALESCE(?, address), postal_code = COALESCE(?, postal_code), province = COALESCE(?, province), city = COALESCE(?, city), orders_count = orders_count + 1, total_spent = total_spent + ?, updated_at = ? WHERE id = ?");
            $stmt->execute([
                $data['name'] ?? null,
                $phone ?: null,
                $data['address'] ?? null,
                $data['postal_code'] ?? null,
                $data['province'] ?? null,
                $data['city'] ?? null,
                $orderTotal,
                $now,
                $existing['id']
            ]);
            jsonResponse(['success' => true, 'message' => 'مشتری بروزرسانی شد', 'customer_id' => $existing['id']]);
        } else {
            $stmt = $db->prepare("INSERT INTO customers (name, email, phone, address, postal_code, province, city, orders_count, total_spent, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)");
            $stmt->execute([
                $data['name'] ?? '',
                $email,
                $phone,
                $data['address'] ?? '',
                $data['postal_code'] ?? '',
                $data['province'] ?? '',
                $data['city'] ?? '',
                floatval($data['order_total'] ?? 0),
                $now,
                $now
            ]);
            jsonResponse(['success' => true, 'message' => 'مشتری ایجاد شد', 'customer_id' => $db->lastInsertId()], 201);
        }
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleUpdateCustomer($id) {
    requireAdmin();
    $db = ensureTables();
    $data = getRequestBody();
    
    $fields = [];
    $values = [];
    $allowed = ['name', 'email', 'phone', 'address', 'postal_code', 'province', 'city', 'is_vip'];
    
    foreach ($data as $key => $value) {
        if (in_array($key, $allowed)) {
            $fields[] = "$key = ?";
            $values[] = $value;
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['success' => false, 'error' => 'داده‌ای ارسال نشده'], 400);
    }
    
    $fields[] = "updated_at = ?";
    $values[] = date('Y-m-d H:i:s');
    $values[] = $id;
    
    try {
        $stmt = $db->prepare("UPDATE customers SET " . implode(', ', $fields) . " WHERE id = ?");
        $stmt->execute($values);
        jsonResponse(['success' => true, 'message' => 'مشتری بروزرسانی شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// --- Coupons ---
function handleGetCoupons() {
    requireAdmin();
    $db = ensureTables();
    
    try {
        $stmt = $db->query("SELECT * FROM coupons ORDER BY created_at DESC");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse(['success' => true, 'data' => $rows]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleCreateCoupon() {
    requireAdmin();
    $db = ensureTables();
    $data = getRequestBody();
    
    if (empty($data['code']) || !isset($data['value'])) {
        jsonResponse(['success' => false, 'error' => 'کد و مقدار تخفیف الزامی است'], 400);
    }
    
    $now = date('Y-m-d H:i:s');
    
    try {
        $stmt = $db->prepare("INSERT INTO coupons (code, type, value, min_purchase, max_discount, usage_limit, is_active, expires_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            strtoupper(trim($data['code'])),
            $data['type'] ?? 'percent',
            floatval($data['value']),
            floatval($data['min_purchase'] ?? 0),
            floatval($data['max_discount'] ?? 0),
            intval($data['usage_limit'] ?? 0),
            $data['is_active'] ?? 1,
            $data['expires_at'] ?? null,
            $now,
            $now
        ]);
        
        jsonResponse(['success' => true, 'message' => 'کد تخفیف ایجاد شد', 'coupon_id' => $db->lastInsertId()], 201);
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'UNIQUE') !== false) {
            jsonResponse(['success' => false, 'error' => 'این کد تخفیف قبلا ثبت شده'], 400);
        }
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleUpdateCoupon($id) {
    requireAdmin();
    $db = ensureTables();
    $data = getRequestBody();
    
    $fields = [];
    $values = [];
    $allowed = ['code', 'type', 'value', 'min_purchase', 'max_discount', 'usage_limit', 'is_active', 'expires_at'];
    
    foreach ($data as $key => $value) {
        if (in_array($key, $allowed)) {
            $fields[] = "$key = ?";
            $values[] = $key === 'code' ? strtoupper(trim($value)) : $value;
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['success' => false, 'error' => 'داده‌ای ارسال نشده'], 400);
    }
    
    $fields[] = "updated_at = ?";
    $values[] = date('Y-m-d H:i:s');
    $values[] = $id;
    
    try {
        $stmt = $db->prepare("UPDATE coupons SET " . implode(', ', $fields) . " WHERE id = ?");
        $stmt->execute($values);
        jsonResponse(['success' => true, 'message' => 'کد تخفیف بروزرسانی شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleDeleteCoupon($id) {
    requireAdmin();
    $db = ensureTables();
    
    try {
        $stmt = $db->prepare("DELETE FROM coupons WHERE id = ?");
        $stmt->execute([$id]);
        jsonResponse(['success' => true, 'message' => 'کد تخفیف حذف شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleValidateCoupon() {
    $db = ensureTables();
    $data = getRequestBody();
    $code = strtoupper(trim($data['code'] ?? ''));
    
    if (!$code) {
        jsonResponse(['success' => false, 'error' => 'کد تخفیف وارد نشده'], 400);
    }
    
    try {
        $stmt = $db->prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1");
        $stmt->execute([$code]);
        $coupon = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$coupon) {
            jsonResponse(['success' => false, 'error' => 'کد تخفیف نامعتبر است']);
        }
        
        // Check expiry
        if ($coupon['expires_at'] && strtotime($coupon['expires_at']) < time()) {
            jsonResponse(['success' => false, 'error' => 'کد تخفیف منقضی شده است']);
        }
        
        // Check usage limit
        if ($coupon['usage_limit'] > 0 && $coupon['used_count'] >= $coupon['usage_limit']) {
            jsonResponse(['success' => false, 'error' => 'ظرفیت استفاده از این کد تمام شده است']);
        }
        
        // Check minimum purchase
        $cartTotal = floatval($data['cart_total'] ?? 0);
        if ($coupon['min_purchase'] > 0 && $cartTotal < $coupon['min_purchase']) {
            jsonResponse(['success' => false, 'error' => 'حداقل مبلغ خرید برای این کد ' . number_format($coupon['min_purchase']) . ' تومان است']);
        }
        
        // Calculate discount
        $discount = 0;
        if ($coupon['type'] === 'percent') {
            $discount = $cartTotal * $coupon['value'] / 100;
            if ($coupon['max_discount'] > 0) {
                $discount = min($discount, $coupon['max_discount']);
            }
        } else {
            $discount = $coupon['value'];
        }
        
        jsonResponse([
            'success' => true,
            'coupon' => [
                'code' => $coupon['code'],
                'type' => $coupon['type'],
                'value' => floatval($coupon['value']),
                'discount' => $discount,
                'max_discount' => floatval($coupon['max_discount'])
            ]
        ]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleUseCoupon() {
    $db = ensureTables();
    $data = getRequestBody();
    $code = strtoupper(trim($data['coupon_code'] ?? $data['code'] ?? ''));
    
    if (!$code) return;
    
    incrementCouponUsage($db, $code);
}

// Increment coupon used_count by code
function incrementCouponUsage($db, $code) {
    $code = strtoupper(trim($code));
    if (!$code) return;
    try {
        $stmt = $db->prepare("UPDATE coupons SET used_count = used_count + 1, updated_at = ? WHERE code = ?");
        $stmt->execute([date('Y-m-d H:i:s'), $code]);
    } catch (PDOException $e) {
        // Silent fail
    }
}

// Decrement coupon used_count by code (for order cancellation)
function decrementCouponUsage($db, $code) {
    $code = strtoupper(trim($code));
    if (!$code) return;
    try {
        $stmt = $db->prepare("UPDATE coupons SET used_count = MAX(0, used_count - 1), updated_at = ? WHERE code = ?");
        $stmt->execute([date('Y-m-d H:i:s'), $code]);
    } catch (PDOException $e) {
        // Silent fail
    }
}

// Deduct inventory for order items
function deductInventory($db, $items) {
    foreach ($items as $item) {
        $productId = $item['id'] ?? $item['product_id'] ?? null;
        $qty = intval($item['quantity'] ?? 1);
        if (!$productId || $qty <= 0) continue;
        try {
            $stmt = $db->prepare("UPDATE products SET quantity = MAX(0, quantity - ?) WHERE id = ?");
            $stmt->execute([$qty, $productId]);
        } catch (PDOException $e) {
            // Silent fail - don't block order
        }
    }
}

// Restore inventory for cancelled order items
function restoreInventory($db, $items) {
    foreach ($items as $item) {
        $productId = $item['id'] ?? $item['product_id'] ?? null;
        $qty = intval($item['quantity'] ?? 1);
        if (!$productId || $qty <= 0) continue;
        try {
            $stmt = $db->prepare("UPDATE products SET quantity = quantity + ? WHERE id = ?");
            $stmt->execute([$qty, $productId]);
        } catch (PDOException $e) {
            // Silent fail
        }
    }
}

// --- Brands ---
function ensureBrandsTable() {
    $db = getDB();
    $db->exec("CREATE TABLE IF NOT EXISTS brands (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT DEFAULT '',
        logo TEXT DEFAULT '',
        created_at TEXT
    )");
    return $db;
}

function handleGetBrands() {
    $db = ensureBrandsTable();
    try {
        $stmt = $db->query("SELECT * FROM brands ORDER BY name ASC");
        $brands = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse(['success' => true, 'data' => $brands]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleCreateBrand() {
    $db = ensureBrandsTable();
    $data = getRequestBody();
    if (empty($data['name'])) {
        jsonResponse(['success' => false, 'error' => 'نام برند الزامی است'], 400);
    }
    try {
        $stmt = $db->prepare("INSERT INTO brands (name, description, logo, created_at) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $data['name'],
            $data['description'] ?? '',
            $data['logo'] ?? '',
            date('Y-m-d H:i:s')
        ]);
        jsonResponse(['success' => true, 'id' => $db->lastInsertId(), 'message' => 'برند اضافه شد'], 201);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleUpdateBrand($id) {
    $db = ensureBrandsTable();
    $data = getRequestBody();
    try {
        $stmt = $db->prepare("UPDATE brands SET name = ?, description = ?, logo = ? WHERE id = ?");
        $stmt->execute([
            $data['name'] ?? '',
            $data['description'] ?? '',
            $data['logo'] ?? '',
            $id
        ]);
        jsonResponse(['success' => true, 'message' => 'برند بروزرسانی شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleDeleteBrand($id) {
    $db = ensureBrandsTable();
    try {
        $stmt = $db->prepare("DELETE FROM brands WHERE id = ?");
        $stmt->execute([$id]);
        jsonResponse(['success' => true, 'message' => 'برند حذف شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// --- Settings ---
function ensureSettingsTable() {
    $db = getDB();
    $db->exec("CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT,
        description TEXT,
        updated_at TEXT
    )");
    return $db;
}

function handleGetSettings() {
    $db = ensureSettingsTable();
    
    try {
        $stmt = $db->query("SELECT key, value FROM settings");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $settings = [];
        foreach ($rows as $row) {
            $decoded = json_decode($row['value'], true);
            $settings[$row['key']] = ($decoded !== null) ? $decoded : $row['value'];
        }
        
        jsonResponse(['success' => true, 'data' => $settings]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

function handleUpdateSettings() {
    requireAdmin();
    $db = ensureSettingsTable();
    $data = getRequestBody();
    
    if (empty($data)) {
        jsonResponse(['success' => false, 'error' => 'داده‌ای ارسال نشده'], 400);
    }
    
    $now = date('Y-m-d H:i:s');
    
    try {
        $stmt = $db->prepare("INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)");
        
        foreach ($data as $key => $value) {
            $storedValue = is_array($value) || is_object($value) || is_bool($value) 
                ? json_encode($value) 
                : (string)$value;
            $stmt->execute([$key, $storedValue, $now]);
        }
        
        jsonResponse(['success' => true, 'message' => 'تنظیمات با موفقیت ذخیره شد']);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

// ==================== Backup Functions ====================
function getBackupDir() {
    $dir = DB_DIR . '/backups';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    return $dir;
}

function handleGetBackupList() {
    requireAdmin();
    $dir = getBackupDir();
    $backups = [];
    
    foreach (glob($dir . '/*.db') as $file) {
        $backups[] = [
            'name' => basename($file),
            'path' => $file,
            'created' => date('Y-m-d H:i:s', filemtime($file)),
            'size_mb' => round(filesize($file) / (1024 * 1024), 3),
            'is_manual' => strpos(basename($file), 'manual') !== false
        ];
    }
    
    usort($backups, function($a, $b) {
        return filemtime($b['path']) - filemtime($a['path']);
    });
    
    jsonResponse(['success' => true, 'data' => $backups]);
}

function handleGetBackupStatus() {
    requireAdmin();
    $dir = getBackupDir();
    $files = glob($dir . '/*.db');
    
    $totalSize = 0;
    $lastBackup = null;
    foreach ($files as $f) {
        $totalSize += filesize($f);
        $mtime = filemtime($f);
        if (!$lastBackup || $mtime > filemtime($lastBackup)) {
            $lastBackup = $f;
        }
    }
    
    jsonResponse(['success' => true, 'data' => [
        'backup_count' => count($files),
        'total_size_mb' => round($totalSize / (1024 * 1024), 3),
        'last_backup' => $lastBackup ? date('Y-m-d H:i:s', filemtime($lastBackup)) : null
    ]]);
}

function handleCreateBackup() {
    requireAdmin();
    $dir = getBackupDir();
    $dbPath = DB_DIR . '/lakra_shop.db';
    
    if (!file_exists($dbPath)) {
        jsonResponse(['success' => false, 'message' => 'فایل دیتابیس یافت نشد'], 404);
    }
    
    $name = 'backup_manual_' . date('Y-m-d_H-i-s') . '.db';
    $dest = $dir . '/' . $name;
    
    if (copy($dbPath, $dest)) {
        jsonResponse(['success' => true, 'message' => 'بکاپ با موفقیت ایجاد شد', 'name' => $name]);
    } else {
        jsonResponse(['success' => false, 'message' => 'خطا در ایجاد بکاپ'], 500);
    }
}

function handleRestoreBackup() {
    requireAdmin();
    $data = getRequestBody();
    $backupName = basename($data['name'] ?? '');
    
    if (!$backupName) {
        jsonResponse(['success' => false, 'message' => 'نام فایل بکاپ الزامی است'], 400);
    }
    
    $backupPath = getBackupDir() . '/' . $backupName;
    $dbPath = DB_DIR . '/lakra_shop.db';
    
    if (!file_exists($backupPath)) {
        jsonResponse(['success' => false, 'message' => 'فایل بکاپ یافت نشد'], 404);
    }
    
    // Create safety backup before restore
    $safetyName = 'backup_before_restore_' . date('Y-m-d_H-i-s') . '.db';
    copy($dbPath, getBackupDir() . '/' . $safetyName);
    
    if (copy($backupPath, $dbPath)) {
        jsonResponse(['success' => true, 'message' => 'بازیابی با موفقیت انجام شد']);
    } else {
        jsonResponse(['success' => false, 'message' => 'خطا در بازیابی بکاپ'], 500);
    }
}

function handleDeleteBackup() {
    requireAdmin();
    $data = getRequestBody();
    $backupName = basename($data['name'] ?? '');
    
    if (!$backupName) {
        jsonResponse(['success' => false, 'message' => 'نام فایل بکاپ الزامی است'], 400);
    }
    
    $backupPath = getBackupDir() . '/' . $backupName;
    
    if (!file_exists($backupPath)) {
        jsonResponse(['success' => false, 'message' => 'فایل بکاپ یافت نشد'], 404);
    }
    
    if (unlink($backupPath)) {
        jsonResponse(['success' => true, 'message' => 'بکاپ با موفقیت حذف شد']);
    } else {
        jsonResponse(['success' => false, 'message' => 'خطا در حذف بکاپ'], 500);
    }
}

// ==================== Router ====================
$endpoint = $_GET['endpoint'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$id = $_GET['id'] ?? null;

// Apply general rate limiting
checkRateLimit('general');

// Route mapping
switch ($endpoint) {
    // Auth
    case 'auth/login':
        if ($method === 'POST') handleLogin();
        break;
    
    case 'auth/register':
        if ($method === 'POST') handleRegister();
        break;
    
    case 'auth/verify':
        if ($method === 'GET') handleVerifyAuth();
        break;
    
    case 'auth/logout':
        if ($method === 'POST') handleLogout();
        break;
    
    // Products
    case 'products':
        switch ($method) {
            case 'GET':
                if ($id) handleGetProduct($id);
                else handleGetProducts();
                break;
            case 'POST':
                handleCreateProduct();
                break;
            case 'PUT':
                if ($id) handleUpdateProduct($id);
                else jsonResponse(['success' => false, 'error' => 'ID محصول الزامی است'], 400);
                break;
            case 'DELETE':
                if ($id) handleDeleteProduct($id);
                else jsonResponse(['success' => false, 'error' => 'ID محصول الزامی است'], 400);
                break;
        }
        break;
    
    // Orders
    case 'orders':
        switch ($method) {
            case 'GET':
                handleGetOrders();
                break;
            case 'POST':
                handleCreateOrder();
                break;
            case 'PUT':
                if ($id) handleUpdateOrderStatus($id);
                else jsonResponse(['success' => false, 'error' => 'ID سفارش الزامی است'], 400);
                break;
        }
        break;
    
    // Reviews
    case 'reviews':
        switch ($method) {
            case 'GET':
                handleGetReviews();
                break;
            case 'POST':
                handleCreateReview();
                break;
            case 'PUT':
                if ($id) handleUpdateReview($id);
                else jsonResponse(['success' => false, 'error' => 'ID نظر الزامی است'], 400);
                break;
            case 'DELETE':
                if ($id) handleDeleteReview($id);
                else jsonResponse(['success' => false, 'error' => 'ID نظر الزامی است'], 400);
                break;
        }
        break;
    
    // Customers
    case 'customers':
        switch ($method) {
            case 'GET':
                handleGetCustomers();
                break;
            case 'POST':
                handleCreateOrUpdateCustomer();
                break;
            case 'PUT':
                if ($id) handleUpdateCustomer($id);
                else jsonResponse(['success' => false, 'error' => 'ID مشتری الزامی است'], 400);
                break;
        }
        break;
    
    // Coupons
    case 'coupons':
        switch ($method) {
            case 'GET':
                handleGetCoupons();
                break;
            case 'POST':
                handleCreateCoupon();
                break;
            case 'PUT':
                if ($id) handleUpdateCoupon($id);
                else jsonResponse(['success' => false, 'error' => 'ID کد تخفیف الزامی است'], 400);
                break;
            case 'DELETE':
                if ($id) handleDeleteCoupon($id);
                else jsonResponse(['success' => false, 'error' => 'ID کد تخفیف الزامی است'], 400);
                break;
        }
        break;
    
    case 'coupons/validate':
        if ($method === 'POST') handleValidateCoupon();
        break;
    
    // Brands
    case 'brands':
        switch ($method) {
            case 'GET':
                handleGetBrands();
                break;
            case 'POST':
                handleCreateBrand();
                break;
            case 'PUT':
                if ($id) handleUpdateBrand($id);
                else jsonResponse(['success' => false, 'error' => 'ID برند الزامی است'], 400);
                break;
            case 'DELETE':
                if ($id) handleDeleteBrand($id);
                else jsonResponse(['success' => false, 'error' => 'ID برند الزامی است'], 400);
                break;
        }
        break;

    // Inventory
    case 'inventory/low-stock':
        if ($method === 'GET') handleGetLowStock();
        break;
    
    case 'inventory/history':
        if ($method === 'GET') handleGetInventoryHistory();
        break;
    
    // Sales
    case 'sales':
        if ($method === 'GET') handleGetSales();
        break;
    
    case 'sales/report':
        if ($method === 'GET') handleGetSalesReport();
        break;
    
    // Stats
    case 'stats/dashboard':
        if ($method === 'GET') handleGetDashboardStats();
        break;
    
    // Upload
    case 'upload/image':
        if ($method === 'POST') handleUploadImage();
        break;
    
    case 'upload/delete':
        if ($method === 'POST') handleDeleteImage();
        break;
    
    // Health
    case 'health':
        handleHealthCheck();
        break;
    
    // Settings
    case 'settings':
        switch ($method) {
            case 'GET':
                handleGetSettings();
                break;
            case 'PUT':
            case 'POST':
                handleUpdateSettings();
                break;
        }
        break;
    
    // Backup
    case 'backup/list':
        if ($method === 'GET') handleGetBackupList();
        break;
    
    case 'backup/status':
        if ($method === 'GET') handleGetBackupStatus();
        break;
    
    case 'backup/create':
        if ($method === 'POST') handleCreateBackup();
        break;
    
    case 'backup/restore':
        if ($method === 'POST') handleRestoreBackup();
        break;
    
    case 'backup/delete':
        if ($method === 'POST') handleDeleteBackup();
        break;
    
    default:
        jsonResponse([
            'success' => false,
            'error' => 'Endpoint نامعتبر',
            'available_endpoints' => [
                'auth/login', 'auth/register', 'auth/verify', 'auth/logout',
                'products', 'orders', 'reviews', 'customers', 'coupons', 'coupons/validate',
                'inventory/low-stock', 'inventory/history',
                'sales', 'sales/report',
                'stats/dashboard',
                'upload/image', 'upload/delete',
                'settings',
                'backup/list', 'backup/status', 'backup/create', 'backup/restore', 'backup/delete',
                'health'
            ]
        ], 404);
}

// If no handler matched
jsonResponse(['success' => false, 'error' => 'متد درخواست نامعتبر'], 405);
